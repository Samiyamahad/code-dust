function setup() {
  createCanvas(400, 300);
  background(0)
}

function draw() {
 
  
  noStroke();
  fill(255, 204, 0);
  circle(mouseX,mouseY,24);
  
}

function mousePressed(){
  background(0);
}