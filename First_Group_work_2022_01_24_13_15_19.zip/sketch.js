function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220,220,0,600);
  fill( 00,)
  ellipse(56, 46, 55, 55);
   fill(175, 100, 220);
  square(250, 200, 55, 20, 15, 10, 5);
 
}